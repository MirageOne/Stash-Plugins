# StashBox Metadata Review

StashBox Metadata Review compares one local Stash record with one or more configured StashBoxes. It shows each returned match alongside the local value, lets you choose a source for each field, checks the local record again before saving, and updates only the fields you selected. It adds a shortcut beside Stash's utility controls and opens a responsive standalone dashboard styled to follow the active Stash theme using the same design system as Library Doctor.

## Requirements and support

- Stash 0.32 or newer, with raw plugin UI assets enabled.
- At least one StashBox configured in **Settings → Metadata Providers**.
- The browser must be signed in to Stash to use the same-origin GraphQL API.
- No additional Python packages or external API credentials are required by this plugin. Configured StashBox credentials are used by Stash's own API and are never requested or stored by the plugin.

The Stash 0.32 GraphQL scraper supports **performers, scenes, studios, and tags**, which are the record types available in this dashboard. Scene lookup first uses Stash's fingerprint matching and falls back to the scene title when no fingerprint result is returned. Groups/movies and scene markers are not offered: Stash 0.32 does not implement a StashBox group scraper operation, and its scraper result does not expose scene markers. Markers can be managed with the separate TPDB Markers plugin.

## Use

1. Open the **StashBox Metadata Review** shortcut in the Stash navigation. If it is not visible after installation, reload the plugin list and refresh the browser.
2. Select a record type, search your local library, and select one record.
3. Choose the configured StashBox sources to query, then select **Compare metadata**.
4. When a source returns several matches, choose the correct one from that source's match list.
5. Select a source value for each field you want to change. Fields are not selected automatically, even when the local value is blank.
6. Review the number of selected fields and choose **Apply selected fields**. If a selected local value changed after the comparison, the update is stopped and the plugin asks you to compare again.

The plugin updates scalar metadata and list values supported by Stash's GraphQL update inputs. It does not create or delete related records, replace relationship lists, choose performer images, or apply updates in bulk. Empty values returned by a source are not used to clear local data. Performer height and weight are converted to integers, aliases are split into Stash lists, and invalid enum or number values are omitted.

## History and privacy

The dashboard keeps the latest 30 applied changes in the current browser's local storage, with the record, source, selected fields, and resulting values. This history is local to that browser profile and is not synced to a Stash account or server. Use **Clear history** to remove it. Source credentials remain in Stash and are not returned to this dashboard; requests use Stash's authenticated `/graphql` endpoint.

## Install

Add the **MirageOne Stash Plugins** source in **Settings → Plugins → Add source** using the index URL in the [repository README](../../README.md), then install **StashBox Metadata Review** from **Available Plugins**. For a manual installation, download [the 1.0.0 manual archive](../../packages/stashbox-metadata-review/1.0.0-manual.zip), extract its `stashbox-metadata-review/` directory into Stash's configured plugin directory, enable it, and refresh Stash in the browser.

## Validation

The bundled dependency-free conversion tests can be run with Node.js:

```sh
node --test plugins/stashbox-metadata-review/tests/core.test.js
```

The tests cover Stash input conversion, safe omission of invalid values, the supported record types, and updates limited to explicitly selected fields.
