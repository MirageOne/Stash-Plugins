(function () {
    "use strict";

    var Core = window.StashBoxReviewCore;
    var THEME_KEY = "stashbox-metadata-review.host-theme.v1";
    var HISTORY_KEY = "stashbox-metadata-review.history.v1";
    var THEME_PROPERTIES = [
        "--ld-bg", "--ld-surface", "--ld-surface-strong", "--ld-border", "--ld-border-strong",
        "--ld-text", "--ld-muted", "--ld-subtle", "--ld-accent", "--ld-accent-contrast",
        "--ld-primary-bg", "--ld-primary-border", "--ld-primary-text", "--ld-accent-bright",
        "--ld-accent-light", "--ld-accent-rgb", "--ld-accent-soft", "--ld-green", "--ld-orange", "--ld-red",
        "--ld-radius", "--ld-radius-sm", "--ld-font", "--ld-button-font", "--ld-button-size",
        "--ld-button-weight", "--ld-button-line-height", "--ld-button-radius"
    ];
    var ACCENTS = { orange: "#d83b01", blue: "#0078d4", pink: "#e3008c", red: "#d13438", yellow: "#f2c811", purple: "#8764b8", green: "#107c10", teal: "#038387" };
    var CONFIG_QUERY = "query StashBoxReviewSources { configuration { general { stashBoxes { name endpoint } } } }";
    var state = {
        type: "performer", sources: [], selectedSources: Object.create(null), local: null, matches: [],
        sourceResults: [], candidateIndex: Object.create(null), choices: Object.create(null), busy: false, history: loadHistory()
    };
    var els = {};

    function byId(id) { return document.getElementById(id); }
    function escapeHtml(value) {
        return String(value == null ? "" : value).replace(/[&<>"']/g, function (character) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[character];
        });
    }
    function getDefinition() { return Core.getEntity(state.type); }
    function displayName(item, type) {
        var config = Core.getEntity(type);
        if (!item || !config) return "";
        return String(item[config.nameField] || "Untitled " + config.label.toLowerCase());
    }
    function formatted(value) {
        if (!Core.hasValue(value)) return "Not set";
        if (Array.isArray(value)) return value.length ? value.join(", ") : "Not set";
        if (typeof value === "object") return JSON.stringify(value);
        return String(value);
    }

    function setError(message) {
        els.error.textContent = message || "";
        els.error.hidden = !message;
    }
    function setStatus(message) {
        els.statusMessage.textContent = message || "";
        els.status.hidden = !message;
    }
    function setBusy(busy, label) {
        state.busy = busy;
        [els.find, els.compare, els.apply, els.refresh].forEach(function (button) { button.disabled = busy; });
        if (busy && label) setStatus(label);
        else if (!busy && label !== false) setStatus("");
        updateButtons();
    }
    function updateButtons() {
        els.find.disabled = state.busy;
        els.refresh.disabled = state.busy;
        els.compare.disabled = state.busy || !state.local || !state.sources.some(function (source) { return state.selectedSources[source.endpoint]; });
        var selectedCount = Object.keys(state.choices).length;
        els.apply.disabled = state.busy || !state.local || selectedCount === 0;
        els.selectionNote.textContent = selectedCount ? selectedCount + " field" + (selectedCount === 1 ? "" : "s") + " selected. The rest of the local record will stay unchanged." : "No fields selected.";
    }

    function graphQLRequest(query, variables) {
        return fetch("/graphql", {
            method: "POST", credentials: "same-origin", cache: "no-store",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: query, variables: variables || {} })
        }).then(function (response) {
            return response.text().then(function (text) {
                var payload;
                try { payload = JSON.parse(text); }
                catch (error) { throw new Error("Stash returned an unreadable response. Confirm you are signed in and reload the page."); }
                if (!response.ok) throw new Error((payload.errors && payload.errors[0] && payload.errors[0].message) || ("Stash returned HTTP " + response.status + "."));
                if (payload.errors && payload.errors.length) throw new Error(payload.errors.map(function (entry) { return entry.message; }).join(" "));
                if (!payload.data) throw new Error("Stash returned no GraphQL data.");
                return payload.data;
            });
        });
    }

    function applyHostTheme() {
        try {
            var snapshot = JSON.parse(localStorage.getItem(THEME_KEY) || "null");
            var root = document.documentElement;
            if (snapshot && snapshot.version === 1 && snapshot.tokens) {
                THEME_PROPERTIES.forEach(function (key) {
                    if (typeof snapshot.tokens[key] === "string" && snapshot.tokens[key]) root.style.setProperty(key, snapshot.tokens[key]);
                });
                if (snapshot.colorScheme === "light" || snapshot.colorScheme === "dark") root.style.colorScheme = snapshot.colorScheme;
                return;
            }
            var older = JSON.parse(localStorage.getItem("stash.theme.tokens.v1") || "null");
            var mapping = { "--ld-bg": "--bg-0", "--ld-surface": "--glass-bg", "--ld-surface-strong": "--glass-bg-strong", "--ld-border": "--glass-border", "--ld-border-strong": "--glass-border-bright", "--ld-text": "--text", "--ld-muted": "--text-muted", "--ld-subtle": "--text-muted", "--ld-accent": "--accent", "--ld-accent-contrast": "--accent-contrast", "--ld-primary-bg": "--accent", "--ld-primary-border": "--accent", "--ld-primary-text": "--accent-contrast", "--ld-accent-bright": "--accent-bright", "--ld-accent-light": "--accent-light", "--ld-accent-rgb": "--accent-rgb", "--ld-accent-soft": "--accent-tint", "--ld-font": "--theme-font-stack", "--ld-radius": "--radius", "--ld-radius-sm": "--radius-sm" };
            var tokens = older && older.version === 1 && older.tokens ? older.tokens : null;
            if (tokens) {
                Object.keys(mapping).forEach(function (key) { if (tokens[mapping[key]]) root.style.setProperty(key, tokens[mapping[key]]); });
                root.style.colorScheme = older.colorScheme || "dark";
            }
            var accent = localStorage.getItem("mv.theme.accent");
            if (accent) root.style.setProperty("--ld-accent", accent);
            var tint = localStorage.getItem("mv.theme.accentTint");
            if (tint) root.style.setProperty("--ld-accent-soft", tint);
            var rgb = localStorage.getItem("mv.theme.accentRgb");
            if (rgb) root.style.setProperty("--ld-accent-rgb", rgb);
            var legacy = localStorage.getItem("fluent-mica.accent");
            if (!accent && legacy && ACCENTS[legacy]) root.style.setProperty("--ld-accent", ACCENTS[legacy]);
        } catch (error) { /* The default Library Doctor palette remains available. */ }
    }

    function queryForSearch(type) {
        var config = Core.getEntity(type);
        return "query StashBoxReviewFind($filter: FindFilterType!) { " + config.localFind + "(filter: $filter) { " + config.list + " { " + config.search + " } } }";
    }
    function queryForOne(type) {
        var config = Core.getEntity(type);
        return "query StashBoxReviewFresh($id: ID!) { " + config.one + "(id: $id) { " + config.search + " } }";
    }
    function queryForScrape(type) {
        var config = Core.getEntity(type);
        var fields = config.fields.map(function (field) { return field[0]; }).filter(function (key, index, all) { return all.indexOf(key) === index; });
        return "query StashBoxReviewScrape($source: ScraperSourceInput!, $input: " + config.scrapeInput + "!) { " + config.scrape + "(source: $source, input: $input) { " + fields.join(" ") + " } }";
    }
    function queryForUpdate(type) {
        var config = Core.getEntity(type);
        return "mutation StashBoxReviewUpdate($input: " + config.updateInput + "!) { " + config.update + "(input: $input) { id } }";
    }
    function scrapeInput(type, local, byName) {
        if (type === "scene" && !byName) return { scene_id: String(local.id) };
        var config = Core.getEntity(type);
        return { query: String(local[config.nameField] || "") };
    }

    function loadSources() {
        return graphQLRequest(CONFIG_QUERY).then(function (data) {
            var general = data.configuration && data.configuration.general;
            state.sources = general && Array.isArray(general.stashBoxes) ? general.stashBoxes.filter(function (source) { return source && source.endpoint; }) : [];
            state.selectedSources = Object.create(null);
            state.sources.forEach(function (source) { state.selectedSources[source.endpoint] = true; });
            renderSources();
            setError("");
            if (!state.sources.length) setStatus("No StashBoxes are configured. Add one under Settings → Metadata Providers, then refresh this page.");
            else setStatus("Loaded " + state.sources.length + " configured StashBox" + (state.sources.length === 1 ? "" : "es") + ".");
        });
    }

    function renderSources() {
        if (!state.sources.length) {
            els.sources.innerHTML = '<p class="sbmr-muted">No configured StashBoxes were found.</p>';
            els.sourceCount.textContent = "";
            updateButtons();
            return;
        }
        els.sources.innerHTML = state.sources.map(function (source, index) {
            return '<label class="sbmr-source-option"><input type="checkbox" data-source-index="' + index + '" ' + (state.selectedSources[source.endpoint] ? "checked" : "") + '><span class="sbmr-source-copy"><strong>' + escapeHtml(source.name || "StashBox " + (index + 1)) + '</strong><small>' + escapeHtml(source.endpoint) + '</small></span></label>';
        }).join("");
        var count = state.sources.filter(function (source) { return state.selectedSources[source.endpoint]; }).length;
        els.sourceCount.textContent = count + " of " + state.sources.length + " selected";
        updateButtons();
    }

    function runSearch() {
        var query = els.search.value.trim();
        if (query.length < 2) { setError("Enter at least two characters to search your local library."); return; }
        setError("");
        setBusy(true, "Searching your local " + getDefinition().label.toLowerCase() + " records…");
        graphQLRequest(queryForSearch(state.type), { filter: { q: query, page: 1, per_page: 30, sort: getDefinition().nameField, direction: "ASC" } })
            .then(function (data) {
                state.matches = data[getDefinition().localFind] ? data[getDefinition().localFind][getDefinition().list] || [] : [];
                renderMatches();
                setStatus(state.matches.length ? "Found " + state.matches.length + " local record" + (state.matches.length === 1 ? "" : "s") + ". Select one to continue." : "No local records matched that search.");
            })
            .catch(function (error) { setError(error.message); })
            .finally(function () { setBusy(false, false); });
    }

    function renderMatches() {
        if (!state.matches.length) { els.results.innerHTML = ""; els.results.hidden = true; return; }
        els.results.innerHTML = state.matches.map(function (item, index) {
            var secondary = item.disambiguation || item.code || item.date || item.details || "";
            return '<button class="sbmr-local-result" type="button" data-local-index="' + index + '"><span><strong>' + escapeHtml(displayName(item, state.type)) + '</strong><small>' + escapeHtml(secondary) + '</small></span><span class="sbmr-result-arrow" aria-hidden="true">›</span></button>';
        }).join("");
        els.results.hidden = false;
    }

    function chooseLocal(index) {
        state.local = state.matches[index] || null;
        state.sourceResults = [];
        state.candidateIndex = Object.create(null);
        state.choices = Object.create(null);
        els.review.hidden = true;
        if (!state.local) { els.selected.hidden = true; updateButtons(); return; }
        var definition = getDefinition();
        var secondary = state.local.disambiguation || state.local.code || state.local.date || "";
        els.selected.innerHTML = '<div class="sbmr-selected-mark" aria-hidden="true">✓</div><div><p class="sbmr-selected-label">Selected local ' + escapeHtml(definition.label.toLowerCase()) + '</p><h3>' + escapeHtml(displayName(state.local, state.type)) + '</h3>' + (secondary ? '<p>' + escapeHtml(secondary) + '</p>' : '') + '</div><button id="sbmr-clear-local" class="ld-button ld-button-quiet" type="button">Change</button>';
        els.selected.hidden = false;
        setStatus("Ready to compare " + displayName(state.local, state.type) + ".");
        updateButtons();
    }

    function compare() {
        if (!state.local) return;
        var selected = state.sources.filter(function (source) { return state.selectedSources[source.endpoint]; });
        if (!selected.length) { setError("Select at least one StashBox source."); return; }
        setError("");
        els.review.hidden = false;
        els.sourceResults.innerHTML = "";
        els.fieldList.innerHTML = '<p class="sbmr-empty">Comparing the selected record with ' + selected.length + ' source' + (selected.length === 1 ? "" : "s") + '…</p>';
        state.sourceResults = [];
        state.candidateIndex = Object.create(null);
        state.choices = Object.create(null);
        setBusy(true, "Comparing metadata with configured StashBoxes…");
        var request = queryForScrape(state.type);
        Promise.all(selected.map(function (source) {
            var variables = { source: { stash_box_endpoint: source.endpoint }, input: scrapeInput(state.type, state.local, false) };
            return graphQLRequest(request, variables).then(function (data) {
                var results = data[getDefinition().scrape] || [];
                if (state.type === "scene" && !results.length && state.local.title) {
                    return graphQLRequest(request, { source: variables.source, input: scrapeInput("scene", state.local, true) }).then(function (nameData) {
                        return { source: source, results: nameData[getDefinition().scrape] || [], searchedByName: true };
                    });
                }
                return { source: source, results: results, searchedByName: false };
            }).catch(function (error) { return { source: source, results: [], error: error.message }; });
        })).then(function (results) {
            state.sourceResults = results;
            results.forEach(function (result) { state.candidateIndex[result.source.endpoint] = 0; });
            renderComparison();
            var hits = results.filter(function (result) { return result.results.length; }).length;
            setStatus("Compared " + results.length + " source" + (results.length === 1 ? "" : "s") + "; " + hits + " returned a match.");
        }).catch(function (error) { setError(error.message); })
            .finally(function () { setBusy(false, false); });
    }

    function candidateFor(result) {
        var index = state.candidateIndex[result.source.endpoint] || 0;
        return result.results[index] || null;
    }
    function candidateName(candidate) {
        if (!candidate) return "No result";
        var keys = ["name", "title"];
        for (var i = 0; i < keys.length; i += 1) if (candidate[keys[i]]) return candidate[keys[i]];
        return "Result " + ((state.candidateIndex["_"] || 0) + 1);
    }
    function renderSourceResults() {
        els.sourceResults.innerHTML = state.sourceResults.map(function (result, sourceIndex) {
            var source = result.source;
            var candidate = candidateFor(result);
            var label = source.name || "StashBox " + (sourceIndex + 1);
            var title = candidate ? candidateName(candidate) : (result.error ? "Source error" : "No match");
            var resultPicker = result.results.length > 1 ? '<label class="sbmr-candidate-picker"><span>Match (' + result.results.length + ')</span><select data-candidate-endpoint="' + escapeHtml(source.endpoint) + '">' + result.results.map(function (entry, index) {
                return '<option value="' + index + '" ' + ((state.candidateIndex[source.endpoint] || 0) === index ? "selected" : "") + '>' + escapeHtml(candidateName(entry)) + (entry.stored_id ? " · matched" : "") + '</option>';
            }).join("") + '</select></label>' : "";
            var stateText = result.error ? result.error : (candidate ? (result.searchedByName ? "Matched using the scene title" : "Metadata returned") : "No match found for this record");
            return '<article class="sbmr-source-card ' + (result.error ? "is-error" : "") + '"><div class="sbmr-source-card-heading"><span class="sbmr-source-icon" aria-hidden="true">' + (candidate ? "✓" : "·") + '</span><div><h3>' + escapeHtml(label) + '</h3><p>' + escapeHtml(title) + '</p></div><span class="sbmr-source-state">' + (candidate ? "Match" : (result.error ? "Error" : "No match")) + '</span></div><p class="sbmr-source-note">' + escapeHtml(stateText) + '</p>' + resultPicker + '</article>';
        }).join("");
    }

    function visibleFields() {
        var definition = getDefinition();
        return definition.fields.map(function (field) {
            var choices = [];
            state.sourceResults.forEach(function (result) {
                var candidate = candidateFor(result);
                if (!candidate) return;
                var normalized = Core.normalizeRemote(state.type, field, candidate[field[0]]);
                if (Core.hasValue(normalized)) choices.push({ source: result.source, candidateIndex: state.candidateIndex[result.source.endpoint] || 0, value: normalized, raw: candidate[field[0]] });
            });
            return { field: field, choices: choices, localValue: Core.normalizeLocal(state.type, field, state.local ? state.local[Core.fieldKey(field)] : null) };
        }).filter(function (row) { return row.choices.length > 0; });
    }

    function renderFieldList() {
        if (!state.local || !state.sourceResults.length) {
            els.fieldList.innerHTML = '<p class="sbmr-empty">No source results to compare.</p>';
            updateButtons();
            return;
        }
        var rows = visibleFields();
        if (!rows.length) {
            els.fieldList.innerHTML = '<div class="sbmr-empty">No fields were returned by the selected sources.</div>';
            updateButtons();
            return;
        }
        els.fieldList.innerHTML = rows.map(function (row) {
            var key = Core.fieldKey(row.field);
            var hasDifferent = row.choices.some(function (choice) { return Core.canonical(choice.value) !== Core.canonical(row.localValue); });
            var buttons = row.choices.map(function (choice) {
                var source = choice.source;
                var active = state.choices[key] && state.choices[key].endpoint === source.endpoint;
                var difference = Core.canonical(choice.value) === Core.canonical(row.localValue);
                return '<button type="button" class="sbmr-value-choice ' + (active ? "is-selected" : "") + '" data-field-key="' + escapeHtml(key) + '" data-endpoint="' + escapeHtml(source.endpoint) + '" aria-pressed="' + Boolean(active) + '"><span class="sbmr-choice-source">' + escapeHtml(source.name || source.endpoint) + '<small>' + (difference ? "Matches local" : "Different") + '</small></span><span class="sbmr-choice-value">' + escapeHtml(formatted(choice.value)) + '</span></button>';
            }).join("");
            return '<article class="sbmr-field-card"><div class="sbmr-field-heading"><h3>' + escapeHtml(row.field[1]) + '</h3><span class="sbmr-diff-badge ' + (hasDifferent ? "is-different" : "") + '">' + (hasDifferent ? "Difference" : "Matches") + '</span></div><div class="sbmr-field-values"><div class="sbmr-local-value"><span class="sbmr-value-label">Current value</span><strong>' + escapeHtml(formatted(row.localValue)) + '</strong></div>' + buttons + '</div></article>';
        }).join("");
        updateButtons();
    }

    function renderComparison() {
        renderSourceResults();
        renderFieldList();
    }

    function freshLocal(type, id) {
        return graphQLRequest(queryForOne(type), { id: String(id) }).then(function (data) { return data[Core.getEntity(type).one]; });
    }

    function applyChoices() {
        var selectedKeys = Object.keys(state.choices);
        if (!selectedKeys.length || !state.local) return;
        var type = state.type;
        var definition = getDefinition();
        setError("");
        setBusy(true, "Checking the local record before applying changes…");
        freshLocal(type, state.local.id).then(function (fresh) {
            if (!fresh) throw new Error("The local record could not be found. Search for it again before applying changes.");
            var remoteValues = {};
            var before = {};
            var sourceNames = [];
            selectedKeys.forEach(function (key) {
                var field = definition.fields.filter(function (entry) { return Core.fieldKey(entry) === key; })[0];
                var choice = state.choices[key];
                var result = state.sourceResults.filter(function (entry) { return entry.source.endpoint === choice.endpoint; })[0];
                var candidate = result && result.results[choice.candidateIndex];
                if (!field || !candidate) throw new Error("A selected source result is no longer available. Run the comparison again.");
                var localKey = Core.fieldKey(field);
                var original = Core.normalizeLocal(type, field, state.local[localKey]);
                var current = Core.normalizeLocal(type, field, fresh[localKey]);
                if (Core.canonical(original) !== Core.canonical(current)) throw new Error("The local " + field[1].toLowerCase() + " changed after comparison. Compare again to review the latest value safely.");
                var nextValue = Core.updateValue(type, field, candidate[field[0]]);
                if (!Core.hasValue(nextValue)) throw new Error("The selected source returned no usable value for " + field[1] + ".");
                remoteValues[localKey] = candidate[field[0]];
                before[localKey] = current;
                if (sourceNames.indexOf(result.source.name || result.source.endpoint) < 0) sourceNames.push(result.source.name || result.source.endpoint);
            });
            var update = Core.buildUpdate(type, fresh.id, remoteValues);
            if (Object.keys(update).length !== selectedKeys.length + 1) throw new Error("One or more selected values could not be safely converted for Stash. Review the fields and compare again.");
            return graphQLRequest(queryForUpdate(type), { input: update }).then(function () {
                return freshLocal(type, state.local.id).then(function (saved) {
                    if (!saved) saved = update;
                    var after = {};
                    selectedKeys.forEach(function (key) {
                        var field = definition.fields.filter(function (entry) { return Core.fieldKey(entry) === key; })[0];
                        after[key] = Core.normalizeLocal(type, field, saved[key]);
                    });
                    var record = {
                        at: new Date().toISOString(), type: type, label: definition.label,
                        entity: displayName(state.local, type), entityId: String(state.local.id),
                        sources: sourceNames, fields: selectedKeys.slice(), before: before, after: after
                    };
                    state.history.unshift(record);
                    state.history = state.history.slice(0, 30);
                    saveHistory();
                    renderHistory();
                    state.local = saved;
                    state.choices = Object.create(null);
                    state.sourceResults = [];
                    els.review.hidden = true;
                    chooseLocalFromFresh(saved);
                    setStatus("Updated " + selectedKeys.length + " field" + (selectedKeys.length === 1 ? "" : "s") + " on " + record.entity + ".");
                });
            });
        }).catch(function (error) { setError(error.message); })
            .finally(function () { setBusy(false, false); });
    }

    function chooseLocalFromFresh(item) {
        var definition = getDefinition();
        var secondary = item.disambiguation || item.code || item.date || "";
        els.selected.innerHTML = '<div class="sbmr-selected-mark" aria-hidden="true">✓</div><div><p class="sbmr-selected-label">Selected local ' + escapeHtml(definition.label.toLowerCase()) + '</p><h3>' + escapeHtml(displayName(item, state.type)) + '</h3>' + (secondary ? '<p>' + escapeHtml(secondary) + '</p>' : '') + '</div><button id="sbmr-clear-local" class="ld-button ld-button-quiet" type="button">Change</button>';
        els.selected.hidden = false;
    }

    function loadHistory() {
        try {
            var records = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
            return Array.isArray(records) ? records.slice(0, 30) : [];
        } catch (error) { return []; }
    }
    function saveHistory() {
        try { localStorage.setItem(HISTORY_KEY, JSON.stringify(state.history)); }
        catch (error) { setStatus("The changes were applied, but browser storage could not save the local history."); }
    }
    function renderHistory() {
        if (!state.history.length) {
            els.history.innerHTML = '<p class="sbmr-muted">No changes yet.</p>';
            els.clearHistory.disabled = true;
            return;
        }
        els.clearHistory.disabled = false;
        els.history.innerHTML = state.history.map(function (record) {
            var date = new Date(record.at);
            var dateText = Number.isNaN(date.getTime()) ? "" : date.toLocaleString();
            var fieldNames = record.fields.map(function (key) {
                var value = record.after[key];
                return '<li><strong>' + escapeHtml(key.replace(/_/g, " ")) + '</strong><span>' + escapeHtml(formatted(value)) + '</span></li>';
            }).join("");
            return '<details class="sbmr-history-entry"><summary><span><strong>' + escapeHtml(record.entity) + '</strong><small>' + escapeHtml(record.label) + ' · ' + record.fields.length + ' field' + (record.fields.length === 1 ? "" : "s") + '</small></span><time>' + escapeHtml(dateText) + '</time></summary><div class="sbmr-history-body"><p>Source: ' + escapeHtml((record.sources || []).join(", ")) + '</p><ul>' + fieldNames + '</ul></div></details>';
        }).join("");
    }

    function bindEvents() {
        els.type.addEventListener("change", function () {
            state.type = els.type.value;
            state.local = null;
            state.matches = [];
            state.sourceResults = [];
            state.choices = Object.create(null);
            els.results.innerHTML = "";
            els.results.hidden = true;
            els.selected.hidden = true;
            els.review.hidden = true;
            setError("");
            setStatus("");
            updateButtons();
        });
        els.find.addEventListener("click", runSearch);
        els.search.addEventListener("keydown", function (event) { if (event.key === "Enter") { event.preventDefault(); runSearch(); } });
        els.results.addEventListener("click", function (event) {
            var button = event.target.closest("[data-local-index]");
            if (button) chooseLocal(Number(button.dataset.localIndex));
        });
        els.selected.addEventListener("click", function (event) {
            if (event.target.closest("#sbmr-clear-local")) {
                state.local = null;
                els.selected.hidden = true;
                els.search.focus();
                updateButtons();
            }
        });
        els.sources.addEventListener("change", function (event) {
            var input = event.target.closest("[data-source-index]");
            if (!input) return;
            var source = state.sources[Number(input.dataset.sourceIndex)];
            if (source) state.selectedSources[source.endpoint] = input.checked;
            var count = state.sources.filter(function (entry) { return state.selectedSources[entry.endpoint]; }).length;
            els.sourceCount.textContent = count + " of " + state.sources.length + " selected";
            updateButtons();
        });
        els.compare.addEventListener("click", compare);
        els.sourceResults.addEventListener("change", function (event) {
            var select = event.target.closest("[data-candidate-endpoint]");
            if (!select) return;
            state.candidateIndex[select.dataset.candidateEndpoint] = Number(select.value);
            renderComparison();
        });
        els.fieldList.addEventListener("click", function (event) {
            var button = event.target.closest("[data-field-key]");
            if (!button) return;
            var key = button.dataset.fieldKey;
            if (state.choices[key] && state.choices[key].endpoint === button.dataset.endpoint) delete state.choices[key];
            else {
                var result = state.sourceResults.filter(function (entry) { return entry.source.endpoint === button.dataset.endpoint; })[0];
                state.choices[key] = { endpoint: button.dataset.endpoint, candidateIndex: state.candidateIndex[button.dataset.endpoint] || 0 };
            }
            renderFieldList();
        });
        els.apply.addEventListener("click", applyChoices);
        els.refresh.addEventListener("click", function () {
            setError("");
            setBusy(true, "Refreshing configured StashBoxes…");
            loadSources().catch(function (error) { setError(error.message); }).finally(function () { setBusy(false, false); });
        });
        els.clearHistory.addEventListener("click", function () {
            state.history = [];
            saveHistory();
            renderHistory();
            setStatus("Local browser history cleared.");
        });
        window.addEventListener("storage", function (event) {
            if ([THEME_KEY, "stash.theme.tokens.v1", "mv.theme.accent", "mv.theme.accentTint", "mv.theme.accentRgb"].indexOf(event.key) >= 0) applyHostTheme();
        });
    }

    function cacheElements() {
        els.type = byId("sbmr-type"); els.search = byId("sbmr-search"); els.find = byId("sbmr-find");
        els.results = byId("sbmr-results"); els.selected = byId("sbmr-selected"); els.sources = byId("sbmr-sources");
        els.sourceCount = byId("sbmr-source-count"); els.compare = byId("sbmr-compare"); els.review = byId("sbmr-review");
        els.sourceResults = byId("sbmr-source-results"); els.fieldList = byId("sbmr-field-list");
        els.selectionNote = byId("sbmr-selection-note"); els.apply = byId("sbmr-apply"); els.error = byId("sbmr-error");
        els.status = byId("sbmr-status"); els.statusMessage = byId("sbmr-status-message"); els.refresh = byId("sbmr-refresh");
        els.history = byId("sbmr-history"); els.clearHistory = byId("sbmr-clear-history");
    }

    function init() {
        cacheElements();
        applyHostTheme();
        bindEvents();
        renderHistory();
        loadSources().catch(function (error) { setError(error.message); els.sources.innerHTML = '<p class="sbmr-muted">Could not load StashBox sources. Refresh to try again.</p>'; })
            .finally(function () { updateButtons(); });
    }

    init();
}());
